#pragma once

#include <atomic>
#include <mutex>
using namespace std;

class rw_mutex {
 public:
  rw_mutex() {
    // Implement me!
  }

  void lock_reader() {
    // Implement me!
  }
  
  void unlock_reader() {
    // Implement me!
  }

  
  void lock() {
    // Implement me!
  }
  
  void unlock() {
    // Implement me!
  }

 private:
  // Give me some private variables!
};
