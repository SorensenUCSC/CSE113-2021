#include <atomic>

class dekkers_mutex {
public:
  dekkers_mutex() {
    // implement me!
  }

  void lock(int tid) {
    // implement me!
  }

  void unlock(int tid) {
    // implement me!
  }

private:
  // Give me some private variables  
};
